/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: safety_interlock.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 12-Nov-2026 21:57:54
 */

#ifndef SAFETY_INTERLOCK_H
#define SAFETY_INTERLOCK_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void safety_interlock_init(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for safety_interlock.h
 *
 * [EOF]
 */
